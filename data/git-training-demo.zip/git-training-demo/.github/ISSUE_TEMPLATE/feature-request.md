---
name: Feature Request
about: Suggest or add new code to the project.
title: ''
labels: enhancement
assignees: ''

---

## Summary

<!--
Please add a summary of the proposed changes including:
- Motivation for this change
- Details of any new Science
- Suggested design implementation
-->

### Motivation for the Change

### Impact of Changes

## Additional Info

<!-- Provide any further information -->
<details>
<summary>Click to expand <b>this section...</b></summary>

```
Please add additional verbose information in this section e.g., references, screenshots etc
```
</details>
